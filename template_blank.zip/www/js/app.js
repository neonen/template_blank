$(document).ready(function(){

    $('.tabs').tabs();

    $('.sidenav').sidenav();

 });